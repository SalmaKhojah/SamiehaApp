@extends('layout.master')

@section('title')
  
  @endsection

  @section('css')

  @endsection

  @section('bar1')
   
  @endsection

  @section('bar2')
   
  @endsection



  @section('content')
   
  @endsection

  @section('scripts')

 @endsection