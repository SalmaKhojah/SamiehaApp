<footer class="main-footer">
    <strong>حقوق النشر &copy; 2022-2023 <a href="#">فريق سميها</a>.</strong>
    كل الحقوق محفوظة.
    <div class="float-left d-none d-sm-inline-block">
      <b>النسخة</b> 0.1
    </div>
  </footer>